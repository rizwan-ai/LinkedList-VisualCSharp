﻿using System;
using static System.Console;
using static System.Convert;

namespace SLL_SumOfNodes_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList list = new LinkedList();
            list.AddLast(5);
            list.AddLast(10);
            list.AddLast(15);
            list.AddLast(20);
            
            WriteLine($"List values are : {list.DisplayList()}");
            WriteLine($"Sum of Nodes is : {list.SumOfNodes()}");

            ReadKey(true);
        }
    }
}