﻿//   Linked-List - Implementation in Visual C#
//3: Insert many Nodes at the beginning of a Singly-Linked-List

using System;
using static System.Console;
using static System.Convert;
using LinkedList;

namespace SLL3_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            SLL obj = new SLL();
            Write("Enter Total Number of Nodes : ");
            int n = ToInt32(ReadLine());
            for (int i = 0; i < n; i++)
            {
                Write($"Enter Value {i + 1} : ");
                object value = ReadLine();
                obj.InsertNodes(value);
                obj.DisplayNodes();
            }

            ReadKey(true);
        }
    }
}
