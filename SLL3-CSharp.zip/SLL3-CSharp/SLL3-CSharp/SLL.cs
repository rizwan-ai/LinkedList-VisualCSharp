﻿using System;
using static System.Console;

namespace LinkedList
{
    public class Node
    {
        public object data; 
        public Node link;     
    }
    public class SLL
    {
        private Node start;
        private Node temp;
        public SLL()
        {
            start = null;
        }
        // Insertion in SLL
        public void InsertNodes(object _data)
        {
            temp = new Node();
            temp.data = _data;    
            temp.link = start;    
            start = temp;
        }
        // Traversing in SLL
        public void DisplayNodes()
        {
            temp = start;
            Write("List is : ");
            while (temp != null)
            {
                Write($"{temp.data} ");
                temp = temp.link;
            }
            WriteLine();
        }
    }
}

// Object Class
// https://docs.microsoft.com/en-us/dotnet/api/system.object?view=netframework-4.7.2
// https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/object