﻿using System;
using static System.Console;

namespace SLL_Max_Min_Node_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList list = new LinkedList();
            list.AddLast(5);
            list.AddLast(2);
            list.AddLast(10);
            list.AddLast(6);
            list.AddLast(1);

            WriteLine($"Max value is : {list.Max()}");
            WriteLine($"Min value is : {list.Min()}");

            ReadKey(true);
        }
    }
}
